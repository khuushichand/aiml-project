# tldw_Server_API/app/api/v1/schemas/prompts_schemas.py
#
# Imports
from typing import List, Optional, Dict, Any
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field, validator
from datetime import datetime
#
# Third-party Imports
#
# Local Imports
#
########################################################################################################################
#
# --- Keyword Schemas ---
class KeywordBase(BaseModel):
    keyword_text: str = Field(..., min_length=1, max_length=100, description="The text of the keyword.")


class KeywordCreate(KeywordBase):
    pass


class KeywordResponse(KeywordBase):
    id: int
    uuid: UUID

    # last_modified: datetime # If you want to expose these
    # version: int

    model_config = ConfigDict(from_attributes=True)  # For compatibility if directly mapping from DB model in future


# --- Prompt Schemas ---
class PromptBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255, description="Unique name of the prompt.")
    author: Optional[str] = Field(None, max_length=100, description="Author of the prompt.")
    details: Optional[str] = Field(None, max_length=4000, description="Detailed description or notes about the prompt.")
    system_prompt: Optional[str] = Field(None, max_length=20000, description="The system part of the prompt.")
    user_prompt: Optional[str] = Field(None, max_length=20000, description="The user part of the prompt.")


class PromptCreate(PromptBase):
    keywords: Optional[List[str]] = Field(None, description="List of keyword strings to associate with the prompt.")


class PromptUpdate(BaseModel):  # For partial updates if we add a PATCH endpoint
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    author: Optional[str] = Field(None, max_length=100)
    details: Optional[str] = Field(None, max_length=4000)
    system_prompt: Optional[str] = Field(None, max_length=20000)
    user_prompt: Optional[str] = Field(None, max_length=20000)
    keywords: Optional[List[str]] = None  # To update keywords


class PromptResponse(PromptBase):
    id: int
    uuid: UUID
    last_modified: datetime
    version: int
    keywords: List[str] = Field(default_factory=list, description="Keywords associated with the prompt.")
    deleted: bool = Field(..., description="Indicates if the prompt is soft-deleted.")

    model_config = ConfigDict(from_attributes=True)


class PromptBriefResponse(BaseModel):
    id: int
    uuid: UUID
    name: str
    author: Optional[str]
    last_modified: datetime

    model_config = ConfigDict(from_attributes=True)


class PaginatedPromptsResponse(BaseModel):
    items: List[PromptBriefResponse]
    total_pages: int
    current_page: int
    total_items: int


class PromptSearchResultItem(PromptResponse):  # Or a more specific search result schema
    relevance_score: Optional[float] = None  # If FTS provides it


class PromptSearchResponse(BaseModel):
    items: List[PromptSearchResultItem]
    total_matches: int
    page: int
    per_page: int


class PromptVersionResponse(BaseModel):
    version: int
    created_at: Optional[datetime] = None
    comment: Optional[str] = None
    name: Optional[str] = None
    author: Optional[str] = None
    details: Optional[str] = None
    system_prompt: Optional[str] = None
    user_prompt: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class ExportResponse(BaseModel):
    message: str
    file_path: Optional[str] = None  # Could be a download link or internal path for admin
    file_content_b64: Optional[str] = None  # For direct download via API


# --- Sync Log (Admin/Debug) ---
class SyncLogEntryResponse(BaseModel):
    change_id: int
    entity: str
    entity_uuid: UUID
    operation: str
    timestamp: datetime
    client_id: str
    version: int
    payload: Optional[Dict[str, Any]]

    model_config = ConfigDict(from_attributes=True)


# --- Import/Export ---
class PromptImportItem(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    content: Optional[str] = None
    details: Optional[str] = None
    author: Optional[str] = Field(None, max_length=100)
    system_prompt: Optional[str] = Field(None, max_length=20000)
    user_prompt: Optional[str] = Field(None, max_length=20000)
    keywords: List[str] = Field(default_factory=list)


class PromptImportRequest(BaseModel):
    prompts: List[PromptImportItem] = Field(..., min_length=1)
    skip_duplicates: bool = False


class PromptImportResponse(BaseModel):
    imported: int
    failed: int
    skipped: int
    prompt_ids: List[int] = Field(default_factory=list)


# --- Template Processing ---
class TemplateVariablesRequest(BaseModel):
    template: str = Field(..., min_length=1)


class TemplateVariablesResponse(BaseModel):
    variables: List[str]


class TemplateRenderRequest(BaseModel):
    template: str = Field(..., min_length=1)
    variables: Dict[str, Any]


class TemplateRenderResponse(BaseModel):
    rendered: str


# --- Bulk Operations ---
class PromptBulkDeleteRequest(BaseModel):
    prompt_ids: List[int] = Field(..., min_length=1)


class PromptBulkDeleteResponse(BaseModel):
    deleted: int
    failed: int
    failed_ids: List[int] = Field(default_factory=list)


class PromptBulkKeywordsRequest(BaseModel):
    prompt_ids: List[int] = Field(..., min_length=1)
    add_keywords: List[str] = Field(default_factory=list)
    remove_keywords: List[str] = Field(default_factory=list)


class PromptBulkKeywordsResponse(BaseModel):
    updated: int
    failed: int
    failed_ids: List[int] = Field(default_factory=list)

#
# End of prompts_schemas.py
#######################################################################################################################

# --- Legacy/compat request models (for endpoints using simple payloads) ---

class LegacyPromptCreateRequest(BaseModel):
    """Legacy payload for creating prompts.

    Supports both 'details' and legacy 'content'.
    """
    model_config = ConfigDict(extra='forbid', populate_by_name=True)

    name: Optional[str] = None
    author: Optional[str] = None
    details: Optional[str] = None
    content: Optional[str] = None
    system_prompt: Optional[str] = None
    user_prompt: Optional[str] = None
    keywords: List[str] = Field(default_factory=list)

    @property
    def effective_details(self) -> Optional[str]:
        return self.details if (self.details and self.details.strip()) else self.content


class CreatePromptCompatRequest(LegacyPromptCreateRequest):
    """Alias for legacy create payload (compat route)."""
    pass


class PromptCollectionCreateRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')

    name: str
    description: Optional[str] = None
    prompt_ids: List[int] = Field(default_factory=list)
